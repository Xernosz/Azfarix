#   Importing stuff
import discord
import json
import random
import os
from discord.ext import commands, tasks
from itertools import cycle
#   Importing stuff

client = commands.Bot(command_prefix= "./")
#   Tasks
client.remove_command("help")

#   Tasks


#   Events
@client.event
async def on_ready():
	await client.change_presence(activity=discord.Game(name=f"Use ./help for a list of commands! Currently in: {len(client.guilds)} servers!"))
	print('Connected to bot: {}'.format(client.user.name))	
	print('Bot ID: {}'.format(client.user.id)) 
	print(f'{round(client.latency * 1000)}ms')
#   Events

#   Commands

##  Ping, Pong!
@client.command(aliases=['latency'])
async def ping(ctx):
    embed=discord.Embed(title="Pong!", description=f'Latency is ```{round(client.latency * 1000)}ms```', color=0xFF5733)
    await ctx.send(embed=embed)
##  Ping, Pong!

##  8ball
@client.command(aliases=['8ball'])
async def _8ball(ctx, *, question):
    responses = [' It is certain.',
 'It is decidedly so.',
 'Without a doubt.',
 'Yes – definitely.',
 'You may rely on it.',
 'As I see it, yes.',
 'Most likely.',
 'Outlook good.',
 'Yes.',
 'Signs point to yes.',
 'Reply hazy, try again.',
 'Ask again later.',
 'Better not tell you now.',
 'Cannot predict now.',
 'Concentrate and ask again.',
 'Don\'t count on it.',
 'My reply is no.',
 'My sources say no.',
 'Outlook not so good.',
 'Very doubtful.',]
    await ctx.send(f'Question: {question} \nAnswer: {random.choice(responses)}'),
#   8ball

##  Clear
@client.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount=5):
    await ctx.channel.purge(limit=amount)
##  Clear


##  Clear all

@client.command()
@commands.has_permissions(manage_messages=True)
async def clearall(ctx, amount=9999999):
    await ctx.channel.purge(limit=amount)
## Clear all

##  Kick
@commands.has_permissions(kick_members=True)
@client.command()
async def kick(ctx, member : discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f'Successfully kicked {member} for {reason}!')
##  Kick

##  Ban
    @commands.has_permissions(ban_members=True)
    @client.command()
    async def ban(ctx, member: discord.Member, *, reason=None):
        await member.ban(reason=reason)
        await ctx.send(f'Successfully banned {member} for {reason}!')
## Ban

##  Unban
        @commands.has_permissions(ban_members=True)
        @client.command()
        async def unban(ctx, *, member):
            banned_users = await ctx.guild.bans()
            member_name, member_discriminator = member.split('#')

            for ban_entry in banned_users:
                user = ban_entry.user


                if (user.name, user.discriminator) == (member_name, member_discriminator):
                    await ctx.guild.unban(user)
                    await ctx.send(f'Succesfully unbanned {user.name}#{user.discriminator}')
##  Unban

##  Help
@client.command()
async def help(ctx):
    embed = discord.Embed(title="Basic Commands", url="https://discord.gg/HMUy5rmkNG",
                          description="There are a couple commands that are not listed here but here are some basic ones!",
                          color=0x3700ff)
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/796823553939865633/799319229416603698/das.png")
    embed.add_field(name="./ping,  ./latency", value="Sends the latency of the bot.", inline=True)
    embed.add_field(name="./8ball {question}", value="You may ask a question and it will respond with a random answer.",
                    inline=True)
    embed.add_field(name="./clear {amount}",
                    value="Must have the MANAGE_MESSAGES permission! Clears a stated amount of messages. If you don't state a number it will delete 4 messages.",
                    inline=True)
    embed.add_field(name="./clearall",
                    value="Must have the MANAGE_MESSAGES permission! Clears all the messages that the bot is able to clear.",
                    inline=True)
    embed.add_field(name="./kick {user} {reason}",
                    value="Must have the KICK_MEMBERS permission! Kicks a designated user either through @mentioning them or putting their ID.",
                    inline=True)
    embed.add_field(name="./ban (always perma you can just unban them via setting a timer) {user} {reason}",
                    value="Must have BAN permission! Bans a designated user through @mentioning them or putting their ID",
                    inline=True)
    embed.add_field(name="./unban {user}",
                    value="Must have BAN permission!  Unbans a designated user by @mentioning them or using their ID",
                    inline=True)
    embed.add_field(name="./help", value="What you are reading right now!", inline=True)
    embed.set_footer(text="Click the title of this embed to be redirected to a support server for this bot.")
    await ctx.send(embed=embed)
##	Help


#   Commands



client.run('Nzk5NDA4MjE5ODYwMzY5NDM5.YADI6w.qsuptdDYDw5ZONcgAfYmqOveXoY')
